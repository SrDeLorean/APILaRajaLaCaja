<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticketpasatiempos extends Model
{
    use HasFactory;

    protected $fillable = [
        'ticket','pasayiempo',
    ];

    public function getTicket()
    {
        return $this->belongsTo(Ticket::class, 'ticket');
    }  

    public function getPasatiempo()
    {
        return $this->belongsTo(Pasatiempo::class, 'pasatiempo');
    }
}
